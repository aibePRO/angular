import { ReversexPipe } from './reversex.pipe';

describe('ReversexPipe', () => {
  it('create an instance', () => {
    const pipe = new ReversexPipe();
    expect(pipe).toBeTruthy();
  });
});
